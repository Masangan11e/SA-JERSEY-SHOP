import express from 'express';
import dotenv from 'dotenv';
import helmet from 'helmet';
import morgan from 'morgan';
import { v4 as uuidv4 } from 'uuid';
import path from 'path';
import fs from 'fs';

dotenv.config();

const app = express();
const PORT = process.env.PORT || 3000;
const __dirname = path.resolve();
const DATA_DIR = path.join(__dirname, 'data');
const ORDERS_FILE = path.join(DATA_DIR, 'orders.json');

if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR);
if (!fs.existsSync(ORDERS_FILE)) fs.writeFileSync(ORDERS_FILE, '[]', 'utf8');

app.use(helmet());
app.use(express.json());
app.use(morgan('dev'));
app.use(express.static(path.join(__dirname, 'public')));

// Health check
app.get('/health', (_, res) => res.json({ ok: true }));

// Build a Peach Payments "Payment Page" link and save a pending order.
// Docs: https://developer.peachpayments.com/docs/payment-page
app.post('/api/checkout', (req, res) => {
  try {
    const { items, customer } = req.body || {};
    if (!Array.isArray(items) || items.length === 0) {
      return res.status(400).json({ error: 'Cart is empty' });
    }
    if (!customer || !customer.firstName || !customer.lastName || !customer.email || !customer.mobile || !customer.address) {
      return res.status(400).json({ error: 'Missing customer details' });
    }

    const currency = process.env.STORE_CURRENCY || 'ZAR';
    const paymentPageId = process.env.PEACH_PAYMENT_PAGE_ID;
    if (!paymentPageId) {
      return res.status(500).json({ error: 'Payment Page ID not configured on server' });
    }

    // Calculate totals server-side to prevent tampering
    const subtotal = items.reduce((sum, it) => sum + (it.price * it.qty), 0);
    const shipping = subtotal >= 1500 ? 0 : 99; // Free shipping over R1500 (edit as needed)
    const total = (subtotal + shipping);

    const orderId = uuidv4();
    const publicBase = process.env.PUBLIC_BASE_URL || `http://localhost:${PORT}`;

    // Save a minimal pending order (in JSON for demo; in production use a database)
    const order = {
      id: orderId,
      status: 'pending_payment',
      createdAt: new Date().toISOString(),
      items,
      customer,
      totals: { subtotal, shipping, total, currency }
    };
    const orders = JSON.parse(fs.readFileSync(ORDERS_FILE, 'utf8'));
    orders.push(order);
    fs.writeFileSync(ORDERS_FILE, JSON.stringify(orders, null, 2), 'utf8');

    // Build a Peach Payment Page URL with prefilled fields.
    // Docs show you can append amount, reference, email, firstName, lastName, mobile as query params.
    const query = new URLSearchParams({
      amount: total.toFixed(2),
      reference: orderId,
      email: customer.email,
      firstName: customer.firstName,
      lastName: customer.lastName,
      mobile: customer.mobile
    }).toString();

    const paymentUrl = `https://page.peachpayments.com/${paymentPageId}?${query}`;

    // Return both payment URL and some order info for client redirect
    res.json({
      ok: true,
      paymentUrl,
      orderId,
      returnUrls: {
        success: `${publicBase}/success.html?orderId=${orderId}`,
        cancel: `${publicBase}/cancelled.html?orderId=${orderId}`
      }
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error creating checkout' });
  }
});

// Webhook endpoint to receive Peach payment notifications (configure in Dashboard)
// For Payment Page, configure your webhook to POST to /api/webhook
app.post('/api/webhook', (req, res) => {
  // In production, verify signature / secret per Peach docs (if available)
  // For demo, we trust payload and update order by reference (orderId)
  try {
    const event = req.body;
    if (!event) return res.status(400).json({ error: 'No payload' });

    const reference = event.reference || event.orderId || event.metadata?.reference;
    const status = event.status || event.paymentStatus || event.event; // adapt to actual payload
    if (!reference) return res.status(400).json({ error: 'Missing reference' });

    const orders = JSON.parse(fs.readFileSync(ORDERS_FILE, 'utf8'));
    const idx = orders.findIndex(o => o.id === reference);
    if (idx === -1) return res.status(404).json({ error: 'Order not found' });

    // Map generic statuses
    let newStatus = orders[idx].status;
    const s = String(status).toLowerCase();
    if (s.includes('success') || s.includes('paid') || s.includes('authorised')) newStatus = 'paid';
    else if (s.includes('failed') || s.includes('declined')) newStatus = 'payment_failed';
    else if (s.includes('cancel')) newStatus = 'cancelled';

    orders[idx].status = newStatus;
    orders[idx].updatedAt = new Date().toISOString();
    fs.writeFileSync(ORDERS_FILE, JSON.stringify(orders, null, 2), 'utf8');

    res.json({ ok: true });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'Webhook processing failed' });
  }
});

// Simple order status lookup page support
app.get('/api/orders/:id', (req, res) => {
  const id = req.params.id;
  const orders = JSON.parse(fs.readFileSync(ORDERS_FILE, 'utf8'));
  const order = orders.find(o => o.id === id);
  if (!order) return res.status(404).json({ error: 'Not found' });
  res.json({ ok: true, order });
});

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
