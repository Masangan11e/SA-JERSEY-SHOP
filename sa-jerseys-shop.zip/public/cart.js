const PRODUCTS = [
  { id: 'mu-home-24', name: 'Manchester United Home 24/25', price: 800, img: 'https://images.unsplash.com/photo-1543326727-cf6c39c8e579?q=80&w=800&auto=format&fit=crop' },
  { id: 'mci-home-24', name: 'Man City Home 24/25', price: 800, img: 'https://images.unsplash.com/photo-1546519638-68e109498ffc?q=80&w=800&auto=format&fit=crop' },
  { id: 'ars-home-24', name: 'Arsenal Home 24/25', price: 800, img: 'https://images.unsplash.com/photo-1502877338535-766e1452684a?q=80&w=800&auto=format&fit=crop' },
  { id: 'rm-home-24', name: 'Real Madrid Home 24/25', price: 800, img: 'https://images.unsplash.com/photo-1522778119026-d647f0596c20?q=80&w=800&auto=format&fit=crop' },
  { id: 'fcb-home-24', name: 'Barcelona Home 24/25', price: 800, img: 'https://images.unsplash.com/photo-1520975916090-3105956dac38?q=80&w=800&auto=format&fit=crop' },
  { id: 'psg-home-24', name: 'PSG Home 24/25', price: 800, img: 'https://images.unsplash.com/photo-1531325223234-45486c781311?q=80&w=800&auto=format&fit=crop' }
];

const formatR = n => 'R' + n.toFixed(0);

const state = {
  cart: []
};

function save() { localStorage.setItem('cart', JSON.stringify(state.cart)); }
function load() { state.cart = JSON.parse(localStorage.getItem('cart') || '[]'); }

function renderProducts() {
  const wrap = document.getElementById('products');
  wrap.innerHTML = PRODUCTS.map(p => `
    <article class="card">
      <img src="${p.img}" alt="${p.name}">
      <div class="p">
        <h4>${p.name}</h4>
        <div class="price">R${p.price}</div>
        <button data-id="${p.id}">Add to cart</button>
      </div>
    </article>
  `).join('');
  wrap.addEventListener('click', e => {
    const id = e.target.dataset.id;
    if (!id) return;
    const product = PRODUCTS.find(x => x.id === id);
    const existing = state.cart.find(x => x.id === id);
    if (existing) existing.qty += 1;
    else state.cart.push({ id, name: product.name, price: product.price, img: product.img, qty: 1 });
    save(); updateCartUI(); openCart();
  });
}

function openCart(){ document.getElementById('cart-drawer').setAttribute('aria-hidden','false'); }
function closeCart(){ document.getElementById('cart-drawer').setAttribute('aria-hidden','true'); }

function updateCartUI(){
  const itemsEl = document.getElementById('cart-items');
  const countEl = document.getElementById('cart-count');
  const subtotalEl = document.getElementById('subtotal');
  const shippingEl = document.getElementById('shipping');
  const totalEl = document.getElementById('total');

  const subtotal = state.cart.reduce((s,i)=>s + i.price*i.qty, 0);
  const shipping = subtotal >= 1500 ? 0 : (subtotal === 0 ? 0 : 99);
  const total = subtotal + shipping;

  countEl.textContent = state.cart.reduce((s,i)=>s+i.qty, 0);
  subtotalEl.textContent = formatR(subtotal);
  shippingEl.textContent = formatR(shipping);
  totalEl.textContent = formatR(total);

  itemsEl.innerHTML = state.cart.map(i => `
    <div class="line">
      <img src="${i.img}" alt="">
      <div>${i.name}</div>
      <div class="qty">
        <button data-action="dec" data-id="${i.id}">-</button>
        <span>${i.qty}</span>
        <button data-action="inc" data-id="${i.id}">+</button>
      </div>
      <div>${formatR(i.price*i.qty)}</div>
    </div>
  `).join('');

  itemsEl.addEventListener('click', e => {
    const action = e.target.dataset.action;
    const id = e.target.dataset.id;
    if (!action) return;
    const line = state.cart.find(x => x.id === id);
    if (!line) return;
    if (action === 'inc') line.qty += 1;
    if (action === 'dec') line.qty -= 1;
    if (line.qty <= 0) state.cart = state.cart.filter(x => x.id !== id);
    save(); updateCartUI();
  });
}

async function checkout(e){
  e.preventDefault();
  if (state.cart.length === 0) return alert('Your cart is empty.');

  const form = e.currentTarget;
  const customer = Object.fromEntries(new FormData(form).entries());
  if (!customer.firstName || !customer.lastName || !customer.email || !customer.mobile || !customer.address){
    return alert('Please complete your delivery details.');
  }

  const res = await fetch('/api/checkout', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ items: state.cart, customer })
  });
  const data = await res.json();
  if (!data.ok) return alert(data.error || 'Checkout error.');

  // Redirect to Peach Payments Payment Page
  window.location.href = data.paymentUrl;
}

function init(){
  load();
  renderProducts();
  updateCartUI();

  document.getElementById('cart-button').addEventListener('click', openCart);
  document.getElementById('close-cart').addEventListener('click', closeCart);
  document.getElementById('checkout-form').addEventListener('submit', checkout);
}

init();
