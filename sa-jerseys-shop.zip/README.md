# SA Jerseys Shop — Peach Payments Starter

A minimal web shop for selling international football jerseys to South African customers.
- Static frontend (HTML/CSS/JS)
- Node.js (Express) backend
- **Peach Payments Payment Page** integration (hosted checkout link).

## Quick start

1. Install Node.js 18+.
2. Copy `.env.example` to `.env` and set:
   - `PEACH_PAYMENT_PAGE_ID` — found in your Peach Dashboard under **Payment Page**.
   - Optional: `PUBLIC_BASE_URL` for deployed URL (used on success/cancel pages).
3. Install deps and run:

```bash
npm install
npm run dev
```

Open http://localhost:3000

## How payments work

- When a buyer clicks **Pay Securely**, the server calculates the total and creates a Payment Page URL:
  `https://page.peachpayments.com/<your-id>?amount=...&reference=<orderId>&email=...&firstName=...&lastName=...&mobile=...`
- The customer is redirected to the **Peach Payments hosted page** to complete payment.
- Configure a webhook in Peach to point to `POST /api/webhook` so paid orders are marked as `paid`.

Docs:
- Peach Payment Page params: https://developer.peachpayments.com/docs/payment-page
- Checkout overview (hosted / embedded): https://developer.peachpayments.com/docs/checkout-overview

## Notes

- This demo saves orders to `data/orders.json`. Use a proper database in production.
- For fully embedded checkout or recurring payments, switch to **Peach Checkout** or **Payments API**.
